
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { EventsComponent } from './events/events.component';
import { ReservationComponent } from './reservation/reservation.component';
import { RoomsComponent } from './rooms/rooms.component';
import {HomeComponent} from './home/home.component';
import { from } from 'rxjs';

const routes: Routes = [
  { path: '', redirectTo: '/HomeComponent', pathMatch: 'full'},
{path: 'reserve',component: ReservationComponent},
{path:'about', component: AboutComponent},
{path:'contact', component: ContactComponent},
{path:'rooms', component: RoomsComponent},
{path:'home', component: HomeComponent},
{path:'app', component:AppComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
