import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-double',
  templateUrl: './double.component.html',
  styleUrls: ['./double.component.css']
})
export class DoubleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
